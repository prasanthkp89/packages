﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using MicroservicesCatalog.Domain.Common;
using MicroservicesCatalog.Domain.Data.Entities;
using MicroservicesCatalog.Domain.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace MicroservicesCatalog.API.Controllers
{
    [ApiController]
    [Route("user")]   
    public class UserController : Controller
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        /// <summary>
        /// Service endpoint used to register a new user 
        /// </summary>
        /// <param name="appUser"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("register")]
        public async Task<ApiResult<string>> Register([FromBody] AppUser appUser)
        {
            return await _userService.SaveUserInfo(appUser);
        }

        /// <summary>
        /// Service endpoint used to valiate existing user 
        /// </summary>
        /// <param name="appUser"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("login")]
        public async Task<ApiResult<AppUser>> Login([FromBody] AppUser appUser)
        {
            return new ApiResult<AppUser>
            {
                StatusCode = HttpStatusCode.OK,
                Data = null
            };
        }

        /// <summary>
        /// Service endpoint used to fetch User Information
        /// </summary>
        /// <param name="appUser"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("details")]
        public async Task<ApiResult<AppUser>> UserDetails([FromBody] AppUser appUser)
        {
            return await _userService.GetUserDetails(appUser);
        }
        
    }
}
