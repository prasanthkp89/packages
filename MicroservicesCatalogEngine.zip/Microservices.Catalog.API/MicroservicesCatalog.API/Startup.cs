using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using MicroservicesCatalog.Domain.Data;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.AspNetCore.Identity;
using MicroservicesCatalog.Domain.Services;
using MicroservicesCatalog.Domain.Data.Repository;

namespace MicroservicesCatalog.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            //services.AddDbContext<MicroservicesCatalog.DomainContext>(options =>
            //{
            //    options.UseMySQL(Configuration.GetConnectionString("DbConnection"),
            //        assembly => assembly.MigrationsAssembly(typeof(MicroservicesCatalog.DomainContext).Assembly.FullName));
            //});


            //services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
            //    .AddEntityFrameworkStores<MicroservicesCatalog.DomainContext>();
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            services.AddOptions();
            services.Configure<Controllers.Audience>(Configuration.GetSection("Audience"));


            #region Services
            services.AddScoped<IUserService, UserService>();            
            #endregion

            #region Repositories
            services.AddScoped<IAppUserRepository, AppUserRepository>();
            #endregion


            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "MicroservicesCatalog.Domain API",
                    Version = "v1",
                    Description = "MicroservicesCatalog.Domain API provides service endpoints to supports MicroservicesCatalog web  application"
                });

                var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                var commentsFilename = Assembly.GetExecutingAssembly().GetName().Name + ".xml";
                var filePath = Path.Combine(baseDirectory, commentsFilename);
                c.IncludeXmlComments(filePath);

            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "MicroservicesCatalog.Domain API V1");
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            app.UseDeveloperExceptionPage();
            //dataContext.Database.Migrate();
        }
    }
}
