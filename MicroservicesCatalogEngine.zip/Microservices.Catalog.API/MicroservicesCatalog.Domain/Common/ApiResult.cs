﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace MicroservicesCatalog.Domain.Common
{
    public class ApiResult<T>
    {
        public HttpStatusCode StatusCode { get; set; }
        public Error Error { get; set; }
        public T Data { get; set; }

        //public ApiResponse Response
        //{
        //    get => new ApiResponse(Data, Error);
        //}
    }

    public class Error
    {
        public HttpStatusCode Code { get; set; }
        public string Message { get; set; }
    }

    public class ApiResponse
    {
        public ApiResponse(object data, Error error)
        {
            Data = data;
            Error = error;
        }

        public object Data { get; set; }

        public Error Error { get; set; }
    }
}
