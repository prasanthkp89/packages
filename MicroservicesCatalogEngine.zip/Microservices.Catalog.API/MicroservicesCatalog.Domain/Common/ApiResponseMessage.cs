﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MicroservicesCatalog.Domain.Common
{
    public class ApiResponseMessage
    {
        public const string StringErrorResponse = null;
        public const string InternalServerError = "Internal Server Error - Something went wrong please try again";
        public const string NoRecordFound = "No record(s) found";
        public const string UniqueIdEmpty = "Unique Id can't be blank";
        public const string AlreadyInUse = "Record is being used";
        public const string AlreadyExists = "Record already exists";
        public const string AlreadyDeleted = "Record is already in disabled state(soft delete) with the provided details";
        public const string InsertSuccess = "Record has been saved successfully";
        public const string InsertFail = "Failed to save record";
        public const string UpdateSuccess = "Record has been updated successfully";
        public const string UpdateFail = "Failed to update record";
        public const string DeleteSuccess = "Record has been deleted successfully";
        public const string DeleteFail = "Failed to delete Record";
        public const string GetFail = "Failed to get the record(s)";
        public const string StatusType = "Status type not found";
        public const string TimeZone = "Timezone not found";
        public const string Country = "Country not found";
        public const string InvalidCredentials = "Invalid Credentials";
    }
}
