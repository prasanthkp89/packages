﻿using MicroservicesCatalog.Domain.Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MicroservicesCatalog.Domain.Data.Repository
{
    public class AppUserRepository: GenericRepository<AppUser>, IAppUserRepository
    {
        #region GlobalVariables
        //private readonly MicroservicesCatalogContext _context = null;
        #endregion
        //public AppUserRepository(MicroservicesCatalogContext MicroservicesCatalogContext)
        //    : base(MicroservicesCatalogContext)
        //{
        //    _context = MicroservicesCatalogContext;
        //}
    }
}
