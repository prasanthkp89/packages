﻿using MicroservicesCatalog.Domain.Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MicroservicesCatalog.Domain.Data.Repository
{
    public interface IAppUserRepository: IGenericRepository<AppUser>
    {
    }
}
