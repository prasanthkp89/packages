﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MicroservicesCatalog.Domain.Data
{
    public interface IGenericRepository<T> where T : class
    {
        Task<IEnumerable<T>> GetAll();
        Task<T> GetById(object id);
        Task<T> Insert(T obj);
        Task InsertAll(IEnumerable<T> objList);
        Task Update(T obj);
        Task Delete(object id);
        Task Save();
    }
}
