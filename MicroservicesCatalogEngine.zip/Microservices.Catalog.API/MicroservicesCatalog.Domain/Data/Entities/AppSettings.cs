﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace MicroservicesCatalog.Domain.Data.Entities
{
    public class AppSettings
    {
        [Key]
        [Column(Order = 0)]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SettingId { get; set; }
        [ForeignKey("IdentityUser")]
        public int Userid { get; set; }
        public bool EnableDigitalLock { get; set; }
        public bool EnableSendAnalytics { get; set; }
        public bool EnableMsgNotifications { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime LastUpdatedOn { get; set; }
    }
}
