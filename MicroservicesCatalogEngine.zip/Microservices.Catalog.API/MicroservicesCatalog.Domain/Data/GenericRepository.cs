﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MicroservicesCatalog.Domain.Data
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        //private readonly MicroservicesCatalog.DomainContext _context = null;
        private readonly DbSet<T> entity = null;

        //public GenericRepository(MicroservicesCatalog.DomainContext context)
        //{
        //    this._context = context;
        //    entity = _context.Set<T>();

        //}

        public async Task<IEnumerable<T>> GetAll()
        {
            return await entity.ToListAsync();

        }

        public async Task<T> GetById(object id)
        {
            return await entity.FindAsync(id);

        }

        public async Task<T> Insert(T obj)
        {
            await entity.AddAsync(obj);
            await this.Save();
            return obj;
        }

        public async Task InsertAll(IEnumerable<T> objList)
        {
            await entity.AddRangeAsync(objList);
            await this.Save();
        }

        public async Task Update(T obj)
        {
            entity.Update(obj);
            await this.Save();
        }

        public async Task Delete(object id)
        {
            T existing = await entity.FindAsync(id);
            entity.Remove(existing);
            await this.Save();
        }

        public async Task Save()
        {
            //await _context.SaveChangesAsync();
        }
    }
}
