﻿using MicroservicesCatalog.Domain.Common;
using MicroservicesCatalog.Domain.Data.Entities;
using MicroservicesCatalog.Domain.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MicroservicesCatalog.Domain.Services
{
    public class UserService : IUserService
    {
        private IAppUserRepository _appUserRepository;
        public UserService(IAppUserRepository appUserRepository)
        {
            _appUserRepository = appUserRepository;
        }
        public async Task<AppUser> GetUserInfo(AppUser appUserInfo)
        {
            try
            {
                var result = (await _appUserRepository.GetAll()).FirstOrDefault(i => i.Username.ToLower() == appUserInfo.Username.ToLower() && i.Password == appUserInfo.Password  && i.IsActive == true);
                return result;
            }
            catch (Exception ex) 
            {
                return null;
            }
        }

        public async Task<ApiResult<AppUser>> GetUserDetails(AppUser appUserInfo)
        {
            try
            {
                var result = (await _appUserRepository.GetAll()).FirstOrDefault(i => (i.Username.ToLower() == appUserInfo.Username.ToLower() || i.Email == appUserInfo.Email || i.MobileNo == appUserInfo.MobileNo) && i.IsActive == true);
                return new ApiResult<AppUser>
                {
                    StatusCode = HttpStatusCode.OK,
                    Data = result
                };
            }
            catch (Exception ex)
            {
                return new ApiResult<AppUser>
                {
                    StatusCode = HttpStatusCode.NoContent,
                    Data = null,
                    Error = new Error()
                    {
                        Code = HttpStatusCode.NoContent,
                        Message = ApiResponseMessage.NoRecordFound.ToString()
                    }
                };
            }
        }

        public async Task<ApiResult<string>> SaveUserInfo(AppUser appUserInfo)
        {
            DateTime UTCTime = System.DateTime.UtcNow;
            DateTime currentDatetime = UTCTime.AddHours(5.5);
            try
            {
                var userExists =  await GetUserDetails(appUserInfo);
                if(userExists != null)
                {
                    return new ApiResult<string>
                    {
                        StatusCode = HttpStatusCode.OK,
                        Data = ApiResponseMessage.AlreadyExists.ToString()
                    };
                }
                else
                {
                    appUserInfo.RegistetredOn = currentDatetime;
                    var appUser = _appUserRepository.Insert(appUserInfo);
                    return new ApiResult<string>
                    {
                        StatusCode = HttpStatusCode.OK,
                        Data = ApiResponseMessage.InsertSuccess.ToString()
                    };
                }                
            }
            catch (Exception ex)
            {
                return new ApiResult<string>
                {
                    StatusCode = HttpStatusCode.BadRequest,
                    Data = null,
                    Error = new Error()
                    {
                        Code = HttpStatusCode.BadRequest,
                        Message = ApiResponseMessage.InsertFail.ToString()
                    }
                };
            }

        }

      

        

        
    }
}
