﻿using MicroservicesCatalog.Domain.Common;
using MicroservicesCatalog.Domain.Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace MicroservicesCatalog.Domain.Services
{
    public interface IUserService
    {
        Task<ApiResult<string>> SaveUserInfo(AppUser appUserInfo);
        Task<AppUser> GetUserInfo(AppUser appUserInfo);
        Task<ApiResult<AppUser>> GetUserDetails(AppUser appUserInfo);
    }
}
