﻿using MicroservicesCatalog.Domain.Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MicroservicesCatalog.Domain.Model.Response
{
    public class UserResponse
    {
        public string Token { get; set; }
        public AppUser UserInfo { get; set; }
    }
}
