import {Component, OnInit, ViewChild, Input} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatSort} from '@angular/material/sort';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from './api.service';

@Component({
  selector: 'application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.css']
})
export class ApplicationComponent {
    constructor (private apiService: ApiService, private route: ActivatedRoute, private _formBuilder: FormBuilder) {}

    public isLinear = true;
    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    thirdFormGroup: FormGroup;
    fourthFormGroup: FormGroup;
    fifthFormGroup: FormGroup;
    sixthFormGrop: FormGroup;
    isEditable = true;

    public serviceData = <any>[];
    public masterData = <any>{};
    public lob; busSvc; supOwn; supGrp; hostLoc; db; os; dc; cicd; env;
    public newApplication = {
        appName: '',
        appDesc: '',
        lob: '',
        busSvc: '',
        supOwn: '',
        supGrp: '',
        hostLoc: '',
        ui: '',
        svrEnv: '',
        db: '',
        mdlwrs: '',
        os: '',
        dc: '',
        repo: '',
        cicd: '',
        env: '',
        sme: '',
        email: '',
    }

    @ViewChild(MatSort, {static: true}) sort: MatSort;

    ngOnInit() {
        this.firstFormGroup = this._formBuilder.group({
            firstCtrl: ['', Validators.required]
        });
        this.secondFormGroup = this._formBuilder.group({
            secondCtrl: ['', Validators.required]
        });
        this.thirdFormGroup = this._formBuilder.group({
            thirdCtrl: ['', Validators.required]
        });
        this.fourthFormGroup = this._formBuilder.group({
            fourthCtrl: ['', Validators.required]
        });
        this.fifthFormGroup = this._formBuilder.group({
            fifthCtrl: ['', Validators.required]
        });
        this.sixthFormGrop = this._formBuilder.group({
            sixthCtrl: ['', Validators.required]
        });

        this.apiService.getApplications().subscribe(data => {this.serviceData = data});
        this.apiService.getMasters().subscribe(data => {
            this.masterData = data; 
            this.lob = this.masterData.data.LineOfBusiness;
            this.busSvc = this.masterData.data.BusinessService;
            this.supOwn = this.masterData.data.SupportOwner;
            this.supGrp = this.masterData.data.SupportGroup;
            this.hostLoc = this.masterData.data.HostLocation;
            this.db = this.masterData.data.Databases;
            this.os = this.masterData.data.OperatingSystem;
            this.dc = this.masterData.data.DataCenters;
            this.cicd = this.masterData.data.CICD;
            this.env = this.masterData.data.Environments;
        });
    }

    create() {
        this.apiService.addApplication(this.newApplication);
    }

    displayedColumns: string[] = ['sn','appName', 'lob', 'busSvc','supGrp','hostLoc','os','actions'];

    public dataSource = this.serviceData;
}
