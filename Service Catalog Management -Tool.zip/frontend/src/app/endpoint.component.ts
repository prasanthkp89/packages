import {Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatDialog} from '@angular/material/dialog';
import { ApiService } from './api.service';

@Component({
  selector: 'endpoint',
  templateUrl: './endpoint.component.html',
  styleUrls: ['./endpoint.component.css']
})
export class EndpointComponent {
    constructor (private apiService: ApiService, private _formBuilder: FormBuilder, 
                private _snackBar: MatSnackBar, public dialog: MatDialog) {}
    
    @ViewChild('button') button: ElementRef;

    firstFormGroup: FormGroup;
    secondFormGroup: FormGroup;
    thirdFormGroup: FormGroup;
    fourthFormGroup: FormGroup;
    fifthFormGroup: FormGroup;
    isEditable = true;
    public result = <any>{};
    public apiData = <any>[];
    public appData = <any>[];
    public serviceData = <any>[];
    public newEndpoint = {
        endpointName: '',
        appData: '',
        srvData: '',
        reqMethod: '',
        reqType: '',
        resType: '',
        reqStruct: '',
        resStruct: '',
        resCodes: '',
        devLLE: '',
        qaLLE: '',
        qeLLE: '',
        perfLLE: '',
        uatLLE: '',
        prod: '',
        health: '',
        swagger: '',
        valid: false,
        URI: '',
    }

    displayedColumns: string[] = ['sn', 'apiName', 'appName', 'srvName', 'reqMethod','reqType','resType','resCodes','validation','actions'];
    public ApplicationList = [
            {
                name: 'Application 1',
                position: 'Person 1',
                weight: 'LOB 1',
                symbol: 'Technology 1'
            },
            {
                name: 'Application 2',
                position: 'Person 1',
                weight: 'LOB 2',
                symbol: 'Technology 2'
            },
            {
                name: 'Application 2',
                position: 'Person 2',
                weight: 'LOB 2',
                symbol: 'Technology 2'
            }
    ]

    ngOnInit() {
        this.firstFormGroup = this._formBuilder.group({
            firstCtrl: ['', Validators.required]
        });
        this.secondFormGroup = this._formBuilder.group({
            secondCtrl: ['', Validators.required]
        });
        this.thirdFormGroup = this._formBuilder.group({
            thirdCtrl: ['', Validators.required]
        });
        this.fourthFormGroup = this._formBuilder.group({
            fourthCtrl: ['', Validators.required]
        });
        this.fifthFormGroup = this._formBuilder.group({
            fifthCtrl: ['', Validators.required]
        });

        this.apiService.getEndpoints().subscribe(data => {
            this.result = data;
            this.apiData = this.result.data
        });

        this.apiService.getServices().subscribe(data => {
            this.result = data;
            this.serviceData = this.result.data
        });

        this.apiService.getApplications().subscribe(data => {
            this.result = data;
            this.appData = this.result.data
        });
    }

    create() {
        this.apiService.addEndpoint(this.newEndpoint);
    }

    validate() {
        this.dialog.open(ConsentEndpointComponent);
    }

    receiveMessage($event) {
        console.log("received");
        console.log("Event: " + $event);
    }
}


@Component({
    selector: 'consentEndpoint',
    templateUrl: 'consentEndpoint.component.html',
    styleUrls: []
})
  
export class ConsentEndpointComponent {
    @Output() messageEvent = new EventEmitter<string>();

    constructor (private _snackBar: MatSnackBar,public dialog: MatDialog) {}

    proceed() {
        this.dialog.open(ValidateEndpointComponent);
    }

    receiveMessage($event) {
        console.log("received 2");
        console.log("Event 2: " + $event);
        this.messageEvent.emit("hello from 2nd child");
    }
    
    close() {
        this.dialog.closeAll();
    }
}

@Component({
    selector: 'validateEndpoint',
    templateUrl: 'validateEndpoint.component.html',
    styleUrls: ['./validateEndpoint.component.css']
})
  
export class ValidateEndpointComponent {
    @Output() messageEvent = new EventEmitter<string>();

    constructor (private _snackBar: MatSnackBar,public dialog: MatDialog) {}
    
    public responseObject = '';
    public response = 
    `
    {
     message: "Fetch Successfull",
     data: {
       name: "ABC",
       age: 12,
       address: "Region/State"
     }
    }
    `;

    public requestObject = 
    `
    {
     request: {
      name: "ABC"
     }
    }
    `;

    validate() {
        // setTimeout(function(){},2000);
        this.responseObject = this.response;
        this.messageEvent.emit("hello from child");
        this._snackBar.open("Service Validation", "Success", {
            duration: 2000,
            verticalPosition: 'bottom'
        });
    }
    
    close() {
        this.dialog.closeAll();
    }
}