import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { ApiService } from './api.service';

@Component({
  selector: 'service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.css']
})
export class ServiceComponent {
    firstFormGroup: FormGroup;
    hideRequiredControl = new FormControl(false);

    constructor (private apiService: ApiService, private _formBuilder: FormBuilder) {
        this.firstFormGroup = this._formBuilder.group({
            firstCtrl: ['', Validators.required]
        });
    }

    public result = <any>{};
    public serviceData = <any>[];
    public masterData = <any>{};
    public appData = <any>[];
    public arch; protocol;
    public newService = {
        srvName: '',
        appData: '',
        architecture: '',
        protocol: '',
        authentication: '',
        coreService: '',
        srvDesc: '',
    }

    ngOnInit() {
        this.apiService.getServices().subscribe(data => {
            this.result = data;
            this.serviceData = this.result.data
        });

        this.apiService.getApplications().subscribe(data => {
            this.result = data;
            this.appData = this.result.data
        });

        this.apiService.getMasters().subscribe(data => {
            this.masterData = data; 
            this.arch = this.masterData.data.Architectures;
            this.protocol = this.masterData.data.Protocols;
        });
    }

    create() {
        this.apiService.addService(this.newService);
    }

    displayedColumns: string[] = ['sn','srvName', 'appName', 'architecture','protocol','authentication','actions'];
}
