import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class ApiService {
    messages = []
    users = []
    path = 'http://localhost:3200/api'

    constructor (private http: HttpClient) {}

    getApplications() {
        return this.http.get(this.path + '/apps');
    }

    getServices() {
        return this.http.get(this.path + '/service');
    }

    getEndpoints() {
        return this.http.get(this.path + '/endpoint');
    }

    getIntegrations() {
        return this.http.get(this.path + '/integration');
    }

    getMasters() {
        return this.http.get(this.path + '/master');
    }

    addApplication(message) {
        this.http.post(this.path + '/apps/add',message).subscribe(res => {});
    }

    addService(message) {
        this.http.post(this.path + '/service/add',message).subscribe(res => {});
    }

    addEndpoint(message) {
        this.http.post(this.path + '/endpoint/add',message).subscribe(res => {});
    }

    addIntegration(message) {
        this.http.post(this.path + '/integration/add',message).subscribe(res => {});
    }

    getMessages(userId) {
        this.http.get<any>(this.path + '/posts/' + userId).subscribe(res => {
            this.messages = res
        })
    }

    postMessage(message) {
        this.http.post(this.path + '/post', message).subscribe(res => {
        })
    }
}