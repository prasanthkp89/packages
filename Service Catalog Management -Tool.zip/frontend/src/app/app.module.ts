import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router'
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatIconModule} from '@angular/material/icon';
import {MatListModule} from '@angular/material/list';
import {MatTableModule} from '@angular/material/table';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import {MatTabsModule} from '@angular/material/tabs';
import {MatButtonModule} from '@angular/material/button';
import {MatChipsModule} from '@angular/material/chips';
import {MatStepperModule} from '@angular/material/stepper';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatBadgeModule} from '@angular/material/badge';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatDialogModule} from '@angular/material/dialog';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatSort} from '@angular/material/sort';
import {MatPaginator} from '@angular/material/paginator';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ApiService } from './api.service';

import { HomeComponent } from './home.component';
import { ApplicationComponent } from './application.component';
import { ServiceComponent } from './service.component';
import { EndpointComponent } from './endpoint.component';
import { IntegrationComponent } from './integration.component';
import { GraphComponent } from './graph.component';
import { DiaglogGraphComponent } from './graph.component';
import { ValidateEndpointComponent } from './endpoint.component';
import { ConsentEndpointComponent } from './endpoint.component';
import { HealthComponent } from './health.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ApplicationComponent,
    ServiceComponent,
    EndpointComponent,
    IntegrationComponent,
    GraphComponent,
    DiaglogGraphComponent,
    ValidateEndpointComponent,
    ConsentEndpointComponent,
    HealthComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatTableModule,
    MatCardModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatTabsModule,
    MatButtonModule,
    MatChipsModule,
    MatStepperModule,
    MatButtonToggleModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatBadgeModule,
    MatCheckboxModule,
    MatDialogModule,
    MatExpansionModule,
    // MatSort,
    // MatPaginator,
    RouterModule.forRoot([
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: 'home', component: HomeComponent},
      { path: 'application', component: ApplicationComponent},
      { path: 'service', component: ServiceComponent},
      { path: 'endpoint', component: EndpointComponent},
      { path: 'integration', component: IntegrationComponent},
      { path: 'graph', component: GraphComponent},
      { path: 'dialogGraph', component: DiaglogGraphComponent},
      { path: 'validateEndpoint', component: ValidateEndpointComponent},
      { path: 'consentEndpoint', component: ConsentEndpointComponent},
      { path: 'health', component: HealthComponent},
      { path: '**', redirectTo: 'home' }
    ])
  ],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { 
  title: 'API Registry'
}
