import {Component, AfterContentInit, OnInit, ViewChild} from '@angular/core';
import {MatSnackBar} from '@angular/material/snack-bar';
import { ApiService } from './api.service';
import * as d3 from 'd3';

@Component({
  selector: 'integration',
  templateUrl: './integration.component.html',
  styleUrls: ['./integration.component.css']
})
export class IntegrationComponent implements OnInit, AfterContentInit{
    constructor (private apiService: ApiService, private _snackBar: MatSnackBar) {}

    displayedColumns: string[] = ['sn', 'sourceApp', 'sourceSrv', 'sourceAPI','integIcon','destApp','destSrv','destAPI','actions'];
    public ApplicationList = [
            {
                name: 'Application 1',
                position: 'Person 1',
                weight: 'LOB 1',
                symbol: 'Technology 1'
            },
            {
                name: 'Application 2',
                position: 'Person 1',
                weight: 'LOB 2',
                symbol: 'Technology 2'
            },
            {
                name: 'Application 2',
                position: 'Person 2',
                weight: 'LOB 2',
                symbol: 'Technology 2'
            }
    ];
    public result = <any>{};
    public apiData = <any>[];
    public appData = <any>[];
    public serviceData = <any>[];
    public integData = <any>[];
    public newIntegration = {
        sourceApp: '',
        sourceSrv: '',
        sourceAPI: '',
        destApp: '',
        destSrv: '',
        destAPI: ''
    }

    public dataSource = this.ApplicationList;

    ngOnInit() {
        this.apiService.getIntegrations().subscribe(data => {
            this.result = data;
            this.integData = this.result.data
        });

        this.apiService.getEndpoints().subscribe(data => {
            this.result = data;
            this.apiData = this.result.data
        });

        this.apiService.getApplications().subscribe(data => {
            this.result = data;
            this.appData = this.result.data
        });
    }

    ngAfterContentInit() {
        this.loadGraph(this.srvData());
    }

    srvData() {
        const data = {
          nodes: [
            {
              id: "Apply Size Service",
              group: "ROC",
              value: 30
            },
            {
              id: "Apply Prepack Service",
              group: "ROC",
              value: 30
            },
            {
              id: "Merch Hierarchy Service",
              group: "MDM",
              value: 30
            },
            {
              id: "Sales Forecast Service",
              group: "XM ",
              value: 30
            }
          ],
          links: [
            {
              source: "Apply Size Service",
              target: "Apply Prepack Service",
              value: 1
            },
            {
              source: "Apply Size Service",
              target: "Merch Hierarchy Service",
              value: 1
            },
            {
              source: "Apply Size Service",
              target: "Sales Forecast Service",
              value: 1
            }
          ]
        }
    
        return data;
    }

    create() {
        this.apiService.addIntegration(this.newIntegration);
    }

    findService(item) {
        this.apiService.getServices().subscribe(data => {
            this.result = data;
            this.serviceData = this.result.data
            // this._snackBar.open("Service Completed", "Fine", {
            //     duration: 2000,
            //     verticalPosition: 'bottom'
            // });
        });
    }

    loadGraph(graph) {
        // console.log("Graph called" + JSON.stringify(graph));
        const label = {
            nodes: [],
            links: []
        };
    
        var width = 1050;
        var height = 550;
        var color = d3.scaleOrdinal(d3.schemeCategory10);
    
        graph.nodes.forEach(function(d, i) {
            label.nodes.push({node: d});
            label.nodes.push({node: d});
            label.links.push({
                source: i * 2,
                target: i * 2 + 1
            });
        });
    
        var labelLayout = d3.forceSimulation(label.nodes)
                            .force("charge", d3.forceManyBody().strength(-50))
                            .force("link", d3.forceLink(label.links).distance(0).strength(1));
    
        var graphLayout = d3.forceSimulation<any>(graph.nodes)
            .force("charge", d3.forceManyBody().strength(-3000))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("x", d3.forceX(width / 2).strength(1))
            .force("y", d3.forceY(height / 2).strength(1))
            .force("link", d3.forceLink<any,any>(graph.links).id(function(d) {return d.id }).distance(1).strength(1))
            .on("tick", ticked);
    
        var adjlist = [];
    
        graph.links.forEach(function(d) {
            adjlist[d.source.index + "-" + d.target.index] = true;
            adjlist[d.target.index + "-" + d.source.index] = true;
        });
    
        function neigh(a, b) {
            return a == b || adjlist[a + "-" + b];
        }
    
        d3.select("#viz").selectAll("*").remove();
        var svg = d3.select("#viz").attr("width", width).attr("height", height);
        var container = svg.append("g");
    
        svg.call(
            d3.zoom()
                .scaleExtent([.1, 4])
                .on("zoom", function() { container.attr("transform", d3.event.transform); })
        );
    
        var link = container.append("g").attr("class", "links")
                            .selectAll("line")
                            .data(graph.links)
                            .enter()
                            .append("line")
                            .attr("stroke", "#aaa")
                            .attr("stroke-width", "1px");
    
        var node = container.append("g").attr("class", "nodes")
                            .selectAll("g")
                            .data(graph.nodes)
                            .enter()
                            .append("circle")
                            .attr("r", 12)
                            // .attr("r", function(d) { return (d as any).value})
                            .attr("fill", function(d) { return color((d as any).group); })
    
        node.on("mouseover", focus).on("mouseout", unfocus);
    
        node.call(
            d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended)
        );
    
        var labelNode = container.append("g").attr("class", "labelNodes")
                                    .selectAll("text")
                                    .data(label.nodes)
                                    .enter()
                                    .append("text")
                                    .text(function(d, i) { return i % 2 == 0 ? "" : d.node.id; })
                                    .style("fill", "#555")
                                    .style("font-family", "Calibri")
                                    .style("font-size", 12)
                                    .style("pointer-events", "none");
    
        node.on("mouseover", focus).on("mouseout", unfocus);
    
        var legend = svg.selectAll(".legend")
            .data(color.domain())
            .enter().append("g")
            .attr("class", "legend")
            .attr("transform", function(d, i) { return "translate(0," + i * 20 + ")"; });
    
        legend.append("rect")
            .attr("x", width - 18)
            .attr("width", 18)
            .attr("height", 18)
            .style("fill", color);
    
        legend.append("text")
            .attr("x", width - 24)
            .attr("y", 9)
            .attr("dy", ".35em")
            .style("text-anchor", "end")
            .text(function(d) { return d; });
    
        // node.on("click", this.displayNode);
    
        function ticked() {
    
            node.call(updateNode);
            link.call(updateLink);
        
            labelLayout.alphaTarget(0.3).restart();
            labelNode.each(function(d, i) {
                if(i % 2 == 0) {
                    d.x = d.node.x;
                    d.y = d.node.y;
                } else {
                    var b = this.getBBox();
                    // var b = {width: 800};
        
                    var diffX = d.x - d.node.x;
                    var diffY = d.y - d.node.y;
        
                    var dist = Math.sqrt(diffX * diffX + diffY * diffY);
        
                    var shiftX = b.width * (diffX - dist) / (dist * 2);
                    shiftX = Math.max(-b.width, Math.min(0, shiftX));
                    var shiftY = 16;
                    this.setAttribute("transform", "translate(" + shiftX + "," + shiftY + ")");
                }
            });
            labelNode.call(updateNode);
        }
    
        function fixna(x) {
            if (isFinite(x)) return x;
            return 0;
        }
        
        function focus(d) {
            var result = d3.select(d3.event.target).datum();
            var index = (result as any).index;
            // var index = d3.select(d3.event.target).datum().index;
            node.style("opacity", function(o) {
                return neigh(index, (o as any).index) ? 1 : 0.1;
            });
            labelNode.attr("display", function(o) {
              return neigh(index, o.node.index) ? "block": "none";
            });
            link.style("opacity", function(o) {
                return (o as any).source.index == index || (o as any).target.index == index ? 1 : 0.1;
            });
        }
    
        function unfocus() {
            labelNode.attr("display", "block");
            node.style("opacity", 1);
            link.style("opacity", 1);
         }
         
        function updateLink(link) {
            link.attr("x1", function(d) { return fixna(d.source.x); })
                .attr("y1", function(d) { return fixna(d.source.y); })
                .attr("x2", function(d) { return fixna(d.target.x); })
                .attr("y2", function(d) { return fixna(d.target.y); });
        }
        
        function updateNode(node) {
            node.attr("transform", function(d) {
                return "translate(" + fixna(d.x) + "," + fixna(d.y) + ")";
            });
        }
    
        function dragstarted(d) {
            d3.event.sourceEvent.stopPropagation();
            if (!d3.event.active) graphLayout.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }
        
        function dragged(d) {
            d.fx = d3.event.x;
            d.fy = d3.event.y;
        }
        
        function dragended(d) {
            if (!d3.event.active) graphLayout.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }
    }
}
