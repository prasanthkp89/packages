/**
 * Function to get authorization config.
 *
 */
export default function config()
{
    return {jwtSecret: 'KOO_2019',
    jwtExpTime: 60 * 10};
}