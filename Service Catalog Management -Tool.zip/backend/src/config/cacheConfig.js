/**
 * Function to configure Cache.
 *
 */

export function cacheConfig() {
    const configParams = {
        cacheKey: '__KOO_2019__',
        cacheTTL: 60
    }
    return configParams;
}