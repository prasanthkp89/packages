import { Router } from 'express';
import * as integration from '../controllers/integration';

const router = Router();

/**
 * POST /api/integration/add.
 */
router.post('/add', integration.create);

/**
 * GET /api/integration.
 */
router.get('/', integration.get);

export default router;