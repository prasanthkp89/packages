import { Router } from 'express';
import * as app from '../controllers/application';

const router = Router();

/**
 * POST /api/apps/add.
 */
router.post('/add', app.create);

/**
 * GET /api/apps.
 */
router.get('/', app.get);

export default router;