import { Router } from 'express';
import * as master from '../controllers/master';

const router = Router();

/**
 * POST /api/apps/add.
 */
router.post('/add', master.create);

/**
 * GET /api/apps.
 */
router.get('/', master.get);

export default router;