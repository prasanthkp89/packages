import { Router } from 'express';
import swaggerSpec from './../utils/swagger';
import userRoutes from './userRoute';
import appRoutes from './application';
import serviceRoutes from './service';
import apiRoutes from './api';
import integRoutes from './integration';
import masterRoutes from './master';

/**
 * Contains all API routes for the application.
 */
const router = Router();

/**
 * GET /api/swagger.json .
 */
router.get('/swagger.json', (req, res) => {
  res.json(swaggerSpec);
});

/**
 * GET /api.
 */
router.get('/', (req, res) => {
  res.json({
    app: req.app.locals.title,
    apiVersion: req.app.locals.version
  });
});

router.use('/users', userRoutes);
router.use('/apps', appRoutes);
router.use('/service',serviceRoutes);
router.use('/master', masterRoutes);
router.use('/endpoint', apiRoutes);
router.use('/integration',integRoutes);

export default router;
