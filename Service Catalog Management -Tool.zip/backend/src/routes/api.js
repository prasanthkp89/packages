import { Router } from 'express';
import * as api from '../controllers/api';

const router = Router();

/**
 * POST /api/service/add.
 */
router.post('/add', api.create);

/**
 * GET /api/service.
 */
router.get('/', api.get);

export default router;