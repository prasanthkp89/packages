import { Router } from 'express';
import * as service from '../controllers/service';

const router = Router();

/**
 * POST /api/service/add.
 */
router.post('/add', service.create);

/**
 * GET /api/service.
 */
router.get('/', service.get);

export default router;