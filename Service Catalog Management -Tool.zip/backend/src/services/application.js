import { uuid } from 'uuidv4';
import apps from '../models/application';
import * as log from '../utils/logger';

/**
 * Get Service.
 */
export async function get() {
    try {
        log.info("Application Service - Get - Start");

        const ApplicationList = await getAllApplications();

        log.info("Application Service - Get - End");

        return ApplicationList;
    } catch (err) {
        log.error("Application Service - Get - Error " + JSON.stringify(err));
    }
}

/**
 * Create Service.
 * 
 * @param {Object} body
 */
export async function create(body) {
    try {
        log.info("Application Service - Create - Start");

        const appData = await formatAppData(body);

        await apps.create(appData);
        
        log.info("Application Service - Create - End");

        return true;
    } catch (err) {
        log.error("Application Service - Create - Error " + JSON.stringify(err));

        return false;
    }
}

/**
 * Format Application Data.
 * 
 * @param {Object} data
 */
function formatAppData(data) {
    log.info("Application Service - formatAppData - Start");

    const appData = {
        ApplicationID: uuid(),
        ApplicationName: (data.appName !== undefined && data.appName !== null) ? data.appName : null,
        Description: (data.appDesc !== undefined && data.appDesc !== null) ? data.appDesc : null,
        LineOfBusiness: (data.lob !== undefined && data.lob !== null) ? data.lob : null,
        BusinessService: (data.busSvc !== undefined && data.busSvc !== null) ? data.busSvc : null,
        SupportOwner: (data.supOwn !== undefined && data.supOwn !== null) ? data.supOwn : null,
        SupportGroup: (data.supGrp !== undefined && data.supGrp !== null) ? data.supGrp : null,
        HostLocation: (data.hostLoc !== undefined && data.hostLoc !== null) ? data.hostLoc : null,
        UserInterfaces: (data.ui !== undefined && data.ui !== null) ? data.ui : null,
        ServerEnvironments: (data.svrEnv !== undefined && data.svrEnv !== null) ? data.svrEnv : null,
        Databases: (data.db !== undefined && data.db !== null) ? data.db : null,
        Middlewares: (data.mdlwrs !== undefined && data.mdlwrs !== null) ? data.mdlwrs : null,
        OperatingSystem: (data.os !== undefined && data.os !== null) ? data.os : null,
        DataCenters: (data.dc !== undefined && data.dc !== null) ? data.dc : null,
        Repository: (data.repo !== undefined && data.repo !== null) ? data.repo : null,
        CICD: (data.cicd !== undefined && data.cicd !== null) ? data.cicd : null,
        Environments: (data.env !== undefined && data.env !== null) ? data.env : null,
        SMEName: (data.sme !== undefined && data.sme !== null) ? data.sme : null,
        SMEEmail: (data.email !== undefined && data.email !== null) ? data.email : null,
        ApplicationServer: (data.appSvr !== undefined && data.appSvr !== null) ? data.appSvr : null,
        ContainerPlatform: (data.cntPlat !== undefined && data.cntPlat !== null) ? data.cntPlat : null
    }

    log.info("Application Service - formatAppData - End");

    return appData;
}

/**
 * Get all applications.
 * 
 */
async function getAllApplications() {
    log.info("Application Service - getAllApplications - Start");
    const ApplicationList = [];

    await apps.find({},function(err,ApplicationDocs) {
        if (!err) {
            if (ApplicationDocs.length > 0) {
                ApplicationDocs.forEach(function (Application) {
                    const ApplicationObj = {
                        appID: Application.ApplicationID,
                        appName: Application.ApplicationName,
                        appDesc: Application.Description,
                        lob: Application.LineOfBusiness,
                        busSvc: Application.BusinessService,
                        supGrp: Application.SupportGroup,
                        supOwn: Application.SupportOwner,
                        hostLoc: Application.HostLocation,
                        ui: Application.UserInterfaces,
                        svrEnv: Application.ServerEnvironments,
                        db: Application.Databases,
                        mdlwrs: Application.Middlewares,
                        os: Application.OperatingSystem,
                        appSvr: Application.ApplicationServer,
                        dc: Application.DataCenters,
                        env: Application.Environments,
                        repo: Application.Repository,
                        cicd: Application.CICD,
                        cntPlat: Application.ContainerPlatform,
                    }

                    ApplicationList.push(ApplicationObj);
                })
            } else {
                log.error("Application Service - getAllApplications - Empty ");
            }
        } else {
            log.error("Application Service - getAllApplications - Error " + JSON.stringify(err));
        }
    })

    log.info("Application Service - getAllApplications - End");

    return ApplicationList;
}