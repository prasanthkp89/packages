import { uuid } from 'uuidv4';
import service from '../models/Service';
import * as log from '../utils/logger';

/**
 * Get Service.
 */
export async function get() {
    try {
        log.info("Services Service - Get - Start");

        const ServicesList = await getAllServices();

        log.info("Services Service - Get - End");

        return ServicesList;
    } catch (err) {
        log.error("Services Service - Get - Error " + JSON.stringify(err));
    }
}

/**
 * Create Service.
 * 
 * @param {Object} body
 */
export async function create(body) {
    try {
        log.info("Services Service - Create - Start");

        const appData = await formatData(body);

        await service.create(appData);
        
        log.info("Services Service - Create - End");

        return true;
    } catch (err) {
        log.error("Services Service - Create - Error " + JSON.stringify(err));

        return false;
    }
}

/**
 * Format Services Data.
 * 
 * @param {Object} data
 */
function formatData(data) {
    log.info("Services Service - formatData - Start");

    const appData = {
        ServiceID: uuid(),
        ServiceName: (data.srvName !== undefined && data.srvName !== null) ? data.srvName : null,
        ApplicationID: (data.appData.appID !== undefined && data.appData.appID !== null) ? data.appData.appID : null,
        ApplicationName: (data.appData.appName !== undefined && data.appData.appName !== null) ? data.appData.appName : null,
        Architecture: (data.architecture !== undefined && data.architecture !== null) ? data.architecture : null,
        Protocol: (data.protocol !== undefined && data.protocol !== null) ? data.protocol : null,
        Authentication: (data.authentication !== undefined && data.authentication !== null) ? data.authentication : null,
        CoreService: (data.coreService !== undefined) ? data.coreService : false,
        Description: (data.srvDesc !== undefined && data.srvDesc !== null) ? data.srvDesc : null,
    }

    log.info("Services Service - formatData - End");

    return appData;
}

/**
 * Get all Servicess.
 * 
 */
async function getAllServices() {
    log.info("Services Service - getAllServices - Start");
    const ServicesList = [];

    await service.find({},function(err,ServicesDocs) {
        if (!err) {
            if (ServicesDocs.length > 0) {
                ServicesDocs.forEach(function (Services) {
                    const ServicesObj = {
                        srvID: Services.ServiceID,
                        srvName: Services.ServiceName,
                        appID: Services.ApplicationID,
                        appName: Services.ApplicationName,
                        architecture: Services.Architecture,
                        protocol: Services.Protocol,
                        authentication: Services.Authentication
                    }

                    ServicesList.push(ServicesObj);
                })
            } else {
                log.error("Services Service - getAllServices - Empty ");
            }
        } else {
            log.error("Services Service - getAllServices - Error " + JSON.stringify(err));
        }
    })

    log.info("Services Service - getAllServices - End");

    return ServicesList;
}