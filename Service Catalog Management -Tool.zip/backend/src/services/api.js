import { uuid } from 'uuidv4';
import api from '../models/api';
import * as log from '../utils/logger';

/**
 * Get Service.
 */
export async function get() {
    try {
        log.info("API Service - Get - Start");

        const APIList = await getAllAPI();

        log.info("API Service - Get - End");

        return APIList;
    } catch (err) {
        log.error("API Service - Get - Error " + JSON.stringify(err));
    }
}

/**
 * Create Service.
 * 
 * @param {Object} body
 */
export async function create(body) {
    try {
        log.info("API Service - Create - Start");

        const appData = await formatData(body);

        await api.create(appData);
        
        log.info("API Service - Create - End");

        return true;
    } catch (err) {
        log.error("API Service - Create - Error " + JSON.stringify(err));

        return false;
    }
}

/**
 * Format API Data.
 * 
 * @param {Object} data
 */
function formatData(data) {
    log.info("API Service - formatData - Start");

    const apiData = {
        EndpointID: uuid(),
        EndPointName: (data.endpointName !== undefined && data.endpointName !== null) ? data.endpointName : null,
        ApplicationID: (data.appData.appID !== undefined && data.appData.appID !== null) ? data.appData.appID : null,
        ApplicationName: (data.appData.appName !== undefined && data.appData.appName !== null) ? data.appData.appName : null,
        ServiceID: (data.srvData.srvID !== undefined && data.srvData.srvID !== null) ? data.srvData.srvID : null,
        ServiceName: (data.srvData.srvName !== undefined && data.srvData.srvName !== null) ? data.srvData.srvName : null,
        RequestMethod: (data.reqMethod !== undefined && data.reqMethod !== null) ? data.reqMethod : null,
        RequestType: (data.reqType !== undefined && data.reqType !== null) ? data.reqType : null,
        ResponseType: (data.resType !== undefined && data.resType !== null) ? data.resType : null,
        RequestStructure: (data.reqStruct !== undefined && data.reqStruct !== null) ? data.reqStruct : null,
        ResponseStructure: (data.resStruct !== undefined && data.resStruct !== null) ? data.resStruct : null,
        ResponseCodes: (data.resCodes !== undefined && data.resCodes !== null) ? data.resCodes : null,
        DevLLE: (data.devLLE !== undefined && data.devLLE !== null) ? data.devLLE : null,
        QALLE: (data.qaLLE !== undefined && data.qaLLE !== null) ? data.qaLLE : null,
        QELLE: (data.qeLLE !== undefined && data.qeLLE !== null) ? data.qeLLE : null,
        PerfLLE: (data.perfLLE !== undefined && data.perfLLE !== null) ? data.perfLLE : null,
        UATLLE: (data.uatLLE !== undefined && data.uatLLE !== null) ? data.uatLLE : null,
        Prod: (data.prod !== undefined && data.prod !== null) ? data.prod : null,
        Health: (data.health !== undefined && data.health !== null) ? data.health : null,
        Swagger: (data.swagger !== undefined && data.swagger !== null) ? data.swagger : null,
        URI: (data.URI !== undefined && data.URI !== null) ? data.URI : null,
    }

    log.info("API Service - formatData - End");

    return apiData;
}

/**
 * Get all APIs.
 * 
 */
async function getAllAPI() {
    log.info("API Service - getAllAPI - Start");
    const APIList = [];

    await api.find({},function(err,APIDocs) {
        if (!err) {
            if (APIDocs.length > 0) {
                APIDocs.forEach(function (API) {
                    const APIObj = {
                        apiID: API.EndpointID,
                        apiName: API.EndPointName,
                        appName: API.ApplicationName,
                        srvName: API.ServiceName,
                        reqMethod: API.RequestMethod,
                        reqType: API.RequestType,
                        resType: API.ResponseType,
                        resCodes: API.ResponseCodes
                    }

                    APIList.push(APIObj);
                })
            } else {
                log.error("API Service - getAllAPI - Empty ");
            }
        } else {
            log.error("API Service - getAllAPI - Error " + JSON.stringify(err));
        }
    })

    log.info("API Service - getAllAPI - End");

    return APIList;
}