import master from '../models/master';
import * as log from '../utils/logger';

/**
 * Get Service.
 */
export async function get() {
    try {
        log.info("Master Service - Get - Start");

        const MasterList = await getAllMasters();

        log.info("Master Service - Get - End");

        return MasterList;
    } catch (err) {
        log.error("Master Service - Get - Error " + JSON.stringify(err));
    }
}

/**
 * Create Service.
 * 
 * @param {Object} body
 */
export async function create(body) {
    try {
        log.info("Master Service - Create - Start");

        const masterObj = formatMaster(body);

        await master.create(masterObj);

        return true;
    } catch (err) {
        log.error("Master Service - Create - Error " + JSON.stringify(err));
    }
}

/**
 * Get all applications.
 * 
 */
async function getAllMasters() {
    log.info("Master Service - getAllMasters - Start");

    const projObj = await master.findOne({id: 1}, function(err,masterDoc) {
        if (!err) {
            return masterDoc;
        } else {
            log.error("Master Service - getAllMasters - Error " + JSON.stringify(err));
        }
    })

    log.info("Master Service - getAllMasters - End");

    return projObj;
}

/**
 * Format Master.
 * 
 * @param {Object} data
 */
function formatMaster(data) {
    log.info("Master Service - formatMaster - Start");
    
    const masterObj = {
        id: 1,
        LineOfBusiness: data.LineOfBusiness,
        BusinessService: data.BusinessService,
        SupportOwner: data.SupportOwner,
        SupportGroup: data.SupportGroup,
        HostLocation: data.HostLocation,
        Databases: data.Databases,
        OperatingSystem: data.OperatingSystem,
        DataCenters: data.DataCenters,
        CICD: data.CICD,
        Environments: data.Environments,
        Architectures: data.Architectures,
        Protocols: data.Protocols
    }
    
    log.info("Master Service - formatMaster - End");

    return masterObj;
}