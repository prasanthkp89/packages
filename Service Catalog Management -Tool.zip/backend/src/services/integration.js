import { uuid } from 'uuidv4';
import integration from '../models/integration';
import * as log from '../utils/logger';

/**
 * Get Service.
 */
export async function get() {
    try {
        log.info("Integrations Service - Get - Start");

        const IntegrationsList = await getAllIntegrations();

        log.info("Integrations Service - Get - End");

        return IntegrationsList;
    } catch (err) {
        log.error("Integrations Service - Get - Error " + JSON.stringify(err));
    }
}

/**
 * Create Service.
 * 
 * @param {Object} body
 */
export async function create(body) {
    try {
        log.info("Integrations Service - Create - Start");

        const appData = await formatData(body);

        await integration.create(appData);
        
        log.info("Integrations Service - Create - End");

        return true;
    } catch (err) {
        log.error("Integrations Service - Create - Error " + JSON.stringify(err));

        return false;
    }
}

/**
 * Format Integrations Data.
 * 
 * @param {Object} data
 */
function formatData(data) {
    log.info("Integrations Service - formatData - Start");

    const integData = {
        IntegrationID: uuid(),
        SourceApplicationID: (data.sourceApp.appID !== undefined && data.sourceApp.appID !== null) ? data.sourceApp.appID : null,
        SourceApplicationName: (data.sourceApp.appName !== undefined && data.sourceApp.appName !== null) ? data.sourceApp.appName : null,
        SourceServiceID: (data.sourceSrv.srvID !== undefined && data.sourceSrv.srvID !== null) ? data.sourceSrv.srvID : null,
        SourceServiceName: (data.sourceSrv.srvName !== undefined && data.sourceSrv.srvName !== null) ? data.sourceSrv.srvName : null,
        SourceEndpointID: (data.sourceAPI.apiID !== undefined && data.sourceAPI.apiID !== null) ? data.sourceAPI.apiID : null,
        SourceEndPointName: (data.sourceAPI.apiName !== undefined && data.sourceAPI.apiName !== null) ? data.sourceAPI.apiName : null,
        DestinationApplicationID: (data.destApp.appID !== undefined && data.destApp.appID !== null) ? data.destApp.appID : null,
        DestinationApplicationName: (data.destApp.appName !== undefined && data.destApp.appName !== null) ? data.destApp.appName : null,
        DestinationServiceID: (data.destSrv.srvID !== undefined && data.destSrv.srvID !== null) ? data.destSrv.srvID : null,
        DestinationServiceName: (data.destSrv.srvName !== undefined && data.destSrv.srvName !== null) ? data.destSrv.srvName : null,
        DestinationEndpointID: (data.destAPI.apiID !== undefined && data.destAPI.apiID !== null) ? data.destAPI.apiID : null,
        DestinationEndPointName: (data.destAPI.apiName !== undefined && data.destAPI.apiName !== null) ? data.destAPI.apiName : null,
    }

    log.info("Integrations Service - formatData - End");

    return integData;
}

/**
 * Get all Integrationss.
 * 
 */
async function getAllIntegrations() {
    log.info("Integrations Service - getAllIntegrations - Start");
    const IntegrationsList = [];

    await integration.find({},function(err,IntegrationsDocs) {
        if (!err) {
            if (IntegrationsDocs.length > 0) {
                IntegrationsDocs.forEach(function (Integrations) {
                    const IntegrationsObj = {
                        sourceApp: Integrations.SourceApplicationName,
                        sourceSrv: Integrations.SourceServiceName,
                        sourceApi: Integrations.SourceEndPointName,
                        destApp: Integrations.DestinationApplicationName,
                        destSrv: Integrations.DestinationServiceName,
                        destApi: Integrations.DestinationEndPointName
                    }

                    IntegrationsList.push(IntegrationsObj);
                })
            } else {
                log.error("Integrations Service - getAllIntegrations - Empty ");
            }
        } else {
            log.error("Integrations Service - getAllIntegrations - Error " + JSON.stringify(err));
        }
    })

    log.info("Integrations Service - getAllIntegrations - End");

    return IntegrationsList;
}