import { connect, Schema, model } from 'mongoose';
import * as log from '../utils/logger';

const db = 'mongodb://localhost:27017/apireg';

connect(db, { useUnifiedTopology: true, useNewUrlParser: true }, function(err) {
    if (err) {
        log.error("DB connection failure " + err);
    }
})

const schema = Schema;
const integSchema = new schema({
    IntegrationID: String,    
    SourceEndpointID: String,
    SourceEndPointName: String,
    SourceApplicationID: String,
    SourceApplicationName: String,
    SourceServiceID: String,
    SourceServiceName: String,
    DestinationEndpointID: String,
    DestinationEndPointName: String,
    DestinationApplicationID: String,
    DestinationApplicationName: String,
    DestinationServiceID: String,
    DestinationServiceName: String,
});

const Integration = model('integrations',integSchema);

export default Integration;