import { connect, Schema, model } from 'mongoose';
import * as log from '../utils/logger';

const db = 'mongodb://localhost:27017/apireg';

connect(db, { useUnifiedTopology: true, useNewUrlParser: true }, function(err) {
    if (err) {
        log.error("DB connection failure " + err);
    }
})

const schema = Schema;
const apiSchema = new schema({
    EndpointID: String,
    EndPointName: String,
    ApplicationID: String,
    ApplicationName: String,
    ServiceID: String,
    ServiceName: String,
    RequestMethod: String,
    RequestType: String,
    ResponseType: String,
    RequestStructure: Object,
    ResponseStructure: Object,
    ResponseCodes: Array,
    DevLLE: String,
    QALLE: String,
    QELLE: String,
    PerfLLE: String,
    UATLLE: String,
    Prod: String,
    Health: String,
    Swagger: String,
    Description: String,
    URI: String,
});

const API = model('apis',apiSchema);

export default API;