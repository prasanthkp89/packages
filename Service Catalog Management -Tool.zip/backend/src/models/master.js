import { connect, Schema, model } from 'mongoose';
import * as log from '../utils/logger';

const db = 'mongodb://localhost:27017/apireg';

connect(db, { useUnifiedTopology: true, useNewUrlParser: true }, function(err) {
    if (err) {
        log.error("DB connection failure " + err);
    }
})

const schema = Schema;
const masterSchema = new schema({
    id: Number,
    LineOfBusiness: Array,
    BusinessService: Array,
    SupportOwner: Array,
    SupportGroup: Array,
    HostLocation: Array,
    Databases: Array,
    OperatingSystem: Array,
    DataCenters: Array,
    CICD: Array,
    Environments: Array,
    Architectures: Array,
    Protocols: Array
});

const Service = model('masters',masterSchema);

export default Service;