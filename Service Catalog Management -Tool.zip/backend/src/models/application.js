import { connect, Schema, model } from 'mongoose';
import * as log from '../utils/logger';

const db = 'mongodb://localhost:27017/apireg';

connect(db, { useUnifiedTopology: true, useNewUrlParser: true }, function(err) {
    if (err) {
        log.error("DB connection failure " + err);
    }
})

const schema = Schema;
const appSchema = new schema({
    ApplicationID: String,
    ApplicationName: String,
    Description: String,
    LineOfBusiness: String,
    BusinessService: String,
    SupportOwner: String,
    SupportGroup: String,
    HostLocation: String,
    UserInterfaces: Array,
    ServerEnvironments: Array,
    Databases: Array,
    Middlewares: Array,
    OperatingSystem: String,
    DataCenters: Array,
    Repository: String,
    CICD: String,
    Environments: Array,
    SMEName: String,
    SMEEmail: String,
    ApplicationServer: String,
    ContainerPlatform: String
});

const Application = model('applications',appSchema);

export default Application;