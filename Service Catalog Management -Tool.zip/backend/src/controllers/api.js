import * as api from '../services/api';
import * as log from '../utils/logger';

/**
 * Get Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function get(req, res, next) {
    try {
        log.info("API Controller - Get - Start");
        
        const result = await api.get();
        
        log.info("API Controller - Get - End");

        res.json({ message: "API(s) Fetched successfully",
                   data: result
        });
    } catch (err) {
        log.error("API Controller - Get - Error " + JSON.stringify(err));
        next(err);
    }
}

/**
 * Create Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function create(req, res, next) {
    try {
        log.info("API Controller - Create - Start");
        
        const result = await api.create(req.body);
        
        log.info("API Controller - Create - End");

        if (result) {
            res.status(200).json({ message: "API(s) Created successfully"});
        } else {
            res.status(500).json({ message: "Internal Server Error"});
        }
    } catch (err) {
        log.error("API Controller - Create - Error " + JSON.stringify(err));
        next(err);
    }
}