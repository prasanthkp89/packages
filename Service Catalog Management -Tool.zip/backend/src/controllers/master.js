import * as master from '../services/master';
import * as log from '../utils/logger';

/**
 * Get Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function get(req, res, next) {
    try {
        log.info("Master Controller - Get - Start");
        
        const result = await master.get();
        
        log.info("Master Controller - Get - End");

        res.json({ message: "Master(s) Fetched successfully",
                   data: result
        });
    } catch (err) {
        log.error("Master Controller - Get - Error " + JSON.stringify(err));
        next(err);
    }
}

/**
 * Create Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function create(req, res, next) {
    try {
        log.info("Master Controller - Create - Start");
        
        const result = await master.create(req.body);
        
        log.info("Master Controller - Create - End");

        if (result) {
            res.status(200).json({ message: "Master(s) Created successfully"});
        } else {
            res.status(500).json({ message: "Internal Server Error"});
        }
    } catch (err) {
        log.error("Master Controller - Create - Error " + JSON.stringify(err));
        next(err);
    }
}