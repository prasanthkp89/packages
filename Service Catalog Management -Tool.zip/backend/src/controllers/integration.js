import * as integration from '../services/integration';
import * as log from '../utils/logger';

/**
 * Get Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function get(req, res, next) {
    try {
        log.info("Integration Controller - Get - Start");
        
        const result = await integration.get();
        
        log.info("Integration Controller - Get - End");

        res.json({ message: "Integration(s) Fetched successfully",
                   data: result
        });
    } catch (err) {
        log.error("Integration Controller - Get - Error " + JSON.stringify(err));
        next(err);
    }
}

/**
 * Create Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function create(req, res, next) {
    try {
        log.info("Integration Controller - Create - Start");
        
        const result = await integration.create(req.body);
        
        log.info("Integration Controller - Create - End");

        if (result) {
            res.status(200).json({ message: "Integration(s) Created successfully"});
        } else {
            res.status(500).json({ message: "Internal Server Error"});
        }
    } catch (err) {
        log.error("Integration Controller - Create - Error " + JSON.stringify(err));
        next(err);
    }
}