import * as app from '../services/application';
import * as log from '../utils/logger';

/**
 * Get Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function get(req, res, next) {
    try {
        log.info("Application Controller - Get - Start");
        
        const result = await app.get();
        
        log.info("Application Controller - Get - End");

        res.json({ message: "Application(s) Fetched successfully",
                   data: result
        });
    } catch (err) {
        log.error("Application Controller - Get - Error " + JSON.stringify(err));
        next(err);
    }
}

/**
 * Create Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function create(req, res, next) {
    try {
        log.info("Application Controller - Create - Start");
        
        const result = await app.create(req.body);
        
        log.info("Application Controller - Create - End");

        if (result) {
            res.status(200).json({ message: "Application(s) Created successfully"});
        } else {
            res.status(500).json({ message: "Internal Server Error"});
        }
    } catch (err) {
        log.error("Application Controller - Create - Error " + JSON.stringify(err));
        next(err);
    }
}