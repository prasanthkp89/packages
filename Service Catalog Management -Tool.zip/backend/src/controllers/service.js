import * as services from '../services/service';
import * as log from '../utils/logger';

/**
 * Get Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function get(req, res, next) {
    try {
        log.info("Service Controller - Get - Start");
        
        const result = await services.get();
        
        log.info("Service Controller - Get - End");

        res.json({ message: "Service(s) Fetched successfully",
                   data: result
        });
    } catch (err) {
        log.error("Service Controller - Get - Error " + JSON.stringify(err));
        next(err);
    }
}

/**
 * Create Controller.
 * 
 * @param {Object} req
 * @param {Object} res
 * @param {Object} next
 */
export async function create(req, res, next) {
    try {
        log.info("Service Controller - Create - Start");
        
        const result = await services.create(req.body);
        
        log.info("Service Controller - Create - End");

        if (result) {
            res.status(200).json({ message: "Service(s) Created successfully"});
        } else {
            res.status(500).json({ message: "Internal Server Error"});
        }
    } catch (err) {
        log.error("Service Controller - Create - Error " + JSON.stringify(err));
        next(err);
    }
}